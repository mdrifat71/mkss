<div class="container">
    <div class="row">
        <div class="col">
            {{-- <div class=" t-center capitalize heading">
                <h2>
                    About Us
                    <span class="circle-left"></span>
                    <span class="circle-right"></span>
                </h2>
            </div> --}}
            <div class="about-body">
                <h2 class="about-heading">lets make the change together</h2>
                <p class="about-text">Lorem Lorem, ipsum dolor sit amet consectetur adipisicing elit. Assumenda odit repellendus asperiores officia eius accusamus error saepe modi magnam ut. ipsum dolor sit amet consectetur adipisicing elit. Aliquid explicabo sed saepe dignissimos in, voluptatum excepturi fugit suscipit illum a.</p>
                <div class="text-center">
                    <a href="/about-us"><button class="joinus-btn cbtn">About Us</button></a>
                </div>
            </div>
        </div>
    </div>
</div>
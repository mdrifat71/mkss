<div class="video-item">
    <iframe width="" height="" src="https://www.youtube.com/embed/tgbNymZ7vqY">
    </iframe>
</div>
<section id="hero">
    <div class="hero-img">
        <img src="{{asset("image/hero.jpg")}}" alt="">
        <div class="overlay"></div>
    </div>
    <div class="motto-container">
        <div class="motto">
            <h1>"Lets Make The Change Together"</h1>
        </div>
        <a href="/project"><button class="explore-btn">explore<i class="fas fa-angle-double-left"></i></button></a>
    </div>
</section>
<div id="top-nav" class="top-nav">
    <div class="container">
        <span class="top-nav-phone">
            <i class="fa fa-phone"></i> 
            {{$mobile}}
        </span>

        <span class="top-nav-email">
            <i class="fa fa-envelope"></i>
            {{$email}}
        </span>
    </div>
</div>


<?php $__env->startSection('main'); ?>
    <?php
       
    ?>
     <?php if (isset($component)) { $__componentOriginal794f920077df0afa5d7c2171f16fd5e1a8d3528f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TopNav::class, []); ?>
<?php $component->withName('top-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal794f920077df0afa5d7c2171f16fd5e1a8d3528f)): ?>
<?php $component = $__componentOriginal794f920077df0afa5d7c2171f16fd5e1a8d3528f; ?>
<?php unset($__componentOriginal794f920077df0afa5d7c2171f16fd5e1a8d3528f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Navigation::class, ['current' => $current]); ?>
<?php $component->withName('navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e)): ?>
<?php $component = $__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e; ?>
<?php unset($__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginalbd6d4d0fcd4660b0447ec3a000aa6bf28aea6570 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Hero::class, []); ?>
<?php $component->withName('hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalbd6d4d0fcd4660b0447ec3a000aa6bf28aea6570)): ?>
<?php $component = $__componentOriginalbd6d4d0fcd4660b0447ec3a000aa6bf28aea6570; ?>
<?php unset($__componentOriginalbd6d4d0fcd4660b0447ec3a000aa6bf28aea6570); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <section id="sectors">
        <div class="container">
            <div class="sectors-title t-center capitalize heading">
                
                <h2>
                    working sectors
                    <span class="circle-left"></span>
                    <span class="circle-right"></span>
                </h2>
            </div>
            <div class="sectors-body">
                <div class="row">
                    
                    <?php $__currentLoopData = $sectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-lg-4 col-md-6 col-sm-12  sectors-container">
                             <?php if (isset($component)) { $__componentOriginal6c783c6a9bbccd588edcb104e5da49c485df935e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Sectors::class, ['image' => $sector->image,'name' => $sector->name]); ?>
<?php $component->withName('sectors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal6c783c6a9bbccd588edcb104e5da49c485df935e)): ?>
<?php $component = $__componentOriginal6c783c6a9bbccd588edcb104e5da49c485df935e; ?>
<?php unset($__componentOriginal6c783c6a9bbccd588edcb104e5da49c485df935e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            <a href="/project?si=<?php echo e($sector->id); ?>" class="sectors-link"></a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    
                </div>
            </div>
        </div>
    </section>

    <section id="about" class="">
         <?php if (isset($component)) { $__componentOriginal2564619d4bc2fbef0e77e853774d397b3351764f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AboutItem::class, []); ?>
<?php $component->withName('about-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal2564619d4bc2fbef0e77e853774d397b3351764f)): ?>
<?php $component = $__componentOriginal2564619d4bc2fbef0e77e853774d397b3351764f; ?>
<?php unset($__componentOriginal2564619d4bc2fbef0e77e853774d397b3351764f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    </section>

    <section id="project">
        <div class="container">
            <div class="project-header heading">
                <h2>
                    project
                    <span class="circle-left"></span>
                    <span class="circle-right"></span>

                </h2>
            </div>
            <div class="project-container">
                <div class="row">
                    
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                             
                            $url = str_replace(" ", "-", $project->title); // create  url from $title
                            $sector = $project->sector;
                            $title  = $project->title;
                            $description = $project->description;
                            $from = $project->from;
                            $to = $project->to;
                            $image = $project->image;
                            $status = $project->status;
                        ?>
                        <div class="col-lg-4 col-md-6 col-sm-12 p project-item-container">
                             <?php if (isset($component)) { $__componentOriginaldba46aec727abc717e342af25f772da50deb1152 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ProjectItem::class, ['title' => $title,'description' => $description,'sector' => $sector,'from' => $from,'to' => $to,'status' => $status,'image' => $image,'url' => $url]); ?>
<?php $component->withName('project-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginaldba46aec727abc717e342af25f772da50deb1152)): ?>
<?php $component = $__componentOriginaldba46aec727abc717e342af25f772da50deb1152; ?>
<?php unset($__componentOriginaldba46aec727abc717e342af25f772da50deb1152); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
            </div>
            <div class="more">
                <a href="/project">
                    <button class="cbtn" title ="view more project"><i class="fas fa-angle-double-right"></i></button>
                </a>
            </div>
        </div>
    </section>


    <section id="video">
        <div class="container">
            <div class="video-title ">
                <h2>Recent Videos</h2>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-12">
                     <?php if (isset($component)) { $__componentOriginal08a55c7cf1b8ee7ff5e92520c1458edf10f87086 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\VideoItem::class, []); ?>
<?php $component->withName('video-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal08a55c7cf1b8ee7ff5e92520c1458edf10f87086)): ?>
<?php $component = $__componentOriginal08a55c7cf1b8ee7ff5e92520c1458edf10f87086; ?>
<?php unset($__componentOriginal08a55c7cf1b8ee7ff5e92520c1458edf10f87086); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                     <?php if (isset($component)) { $__componentOriginal08a55c7cf1b8ee7ff5e92520c1458edf10f87086 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\VideoItem::class, []); ?>
<?php $component->withName('video-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal08a55c7cf1b8ee7ff5e92520c1458edf10f87086)): ?>
<?php $component = $__componentOriginal08a55c7cf1b8ee7ff5e92520c1458edf10f87086; ?>
<?php unset($__componentOriginal08a55c7cf1b8ee7ff5e92520c1458edf10f87086); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                     <?php if (isset($component)) { $__componentOriginal08a55c7cf1b8ee7ff5e92520c1458edf10f87086 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\VideoItem::class, []); ?>
<?php $component->withName('video-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal08a55c7cf1b8ee7ff5e92520c1458edf10f87086)): ?>
<?php $component = $__componentOriginal08a55c7cf1b8ee7ff5e92520c1458edf10f87086; ?>
<?php unset($__componentOriginal08a55c7cf1b8ee7ff5e92520c1458edf10f87086); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                </div>
            </div>
        </div>
    </section>



    <section id="news">
        <div class="heading news-heading">
            <h2>
                news
                <span class="circle-left"></span>
                <span class="circle-right"></span>
            </h2>
        </div>

        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $title = $n->title;
                        $description = $n->description;
                        $image = $n->image;
                        $category = $n->category;
                        $date = $n->created_at;
                        $date = substr($date, 0, 10);
                    ?>
                   <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="news-item-container">
                         <?php if (isset($component)) { $__componentOriginaldacbb302aa06f1655071de43d667fac31a298682 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\NewsItem::class, ['title' => $title,'description' => $description,'image' => $image,'category' => $category,'date' => $date]); ?>
<?php $component->withName('news-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginaldacbb302aa06f1655071de43d667fac31a298682)): ?>
<?php $component = $__componentOriginaldacbb302aa06f1655071de43d667fac31a298682; ?>
<?php unset($__componentOriginaldacbb302aa06f1655071de43d667fac31a298682); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
            <div class="more">
                <a href="/news">
                    <button class="cbtn" title ="view more news"><i class="fas fa-angle-double-right"></i></button>
                </a>
            </div>
        </div>
    </section>


    <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
       
    <?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.app', ["page_title" => "MKSS-Manob Kollan Sabolombi Sangstha"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rifat\Desktop\MKSSDEV\mkss\resources\views/public/pages/home.blade.php ENDPATH**/ ?>
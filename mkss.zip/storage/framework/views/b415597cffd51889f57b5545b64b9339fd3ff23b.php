<div id="top-nav" class="top-nav">
    <div class="container">
        <span class="top-nav-phone">
            <i class="fa fa-phone"></i> 
            <?php echo e($mobile); ?>

        </span>

        <span class="top-nav-email">
            <i class="fa fa-envelope"></i>
            <?php echo e($email); ?>

        </span>
    </div>
</div><?php /**PATH C:\Users\rifat\Desktop\MKSSDEV\mkss\resources\views/public/components/top-nav.blade.php ENDPATH**/ ?>
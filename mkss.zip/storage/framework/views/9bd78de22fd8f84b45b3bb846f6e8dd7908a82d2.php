<div class="video-item">
    <iframe width="" height="" src="https://www.youtube.com/embed/tgbNymZ7vqY">
    </iframe>
</div><?php /**PATH C:\Users\rifat\Desktop\MKSSDEV\mkss\resources\views/public/components/video-item.blade.php ENDPATH**/ ?>
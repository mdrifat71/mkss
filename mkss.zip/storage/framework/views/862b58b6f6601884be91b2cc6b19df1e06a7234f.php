

<?php $__env->startSection('main'); ?>
     <?php if (isset($component)) { $__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Navigation::class, ['current' => $current]); ?>
<?php $component->withName('navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e)): ?>
<?php $component = $__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e; ?>
<?php unset($__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <div id="project-page">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 pr-5 project-page-sidebar">
                    <div class="project-page-sidebar-heading">
                        <h2>
                            Sector
                        </h2>
                    </div>
                    <div class="project-page-side-bar"> 
                        <a href="/project?si=all"><i class="fa fa-plus-square" aria-hidden="true"></i>All</a> 
                        <?php $__currentLoopData = $sectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="/project?si=<?php echo e($sector->id); ?>"><i class="fa fa-plus-square" aria-hidden="true"></i><?php echo e($sector->name); ?> <span class="badge badge-dark"><?php echo e($sector->totalproject); ?></span></a>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                       
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="project-page-heading">
                        <h2><i class="fas fa-project-diagram"></i>Project we have done</h2>
                    </div>
                    <div class="row">
                        <?php if(count($projects) == 0): ?>
                            <div class="alert alert-danger ml-4 mb-5 no-project-alert">
                                Sorry No Projects Found
                            </div>
                        <?php else: ?>
                            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    
                                    $url = str_replace(" ", "-", $project->title); // create  url from $title
                                    $sector = $project->name;
                                    $title  = $project->title;
                                    $description = $project->description;
                                    $from = $project->from;
                                    $to = $project->to;
                                    $image = $project->image;
                                    $status = $project->status;
                                ?>
                                <div class="col-lg-4 col-md-6">
                                     <?php if (isset($component)) { $__componentOriginaldba46aec727abc717e342af25f772da50deb1152 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ProjectItem::class, ['title' => $title,'description' => $description,'sector' => $sector,'from' => $from,'to' => $to,'status' => $status,'image' => $image,'url' => $url]); ?>
<?php $component->withName('project-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginaldba46aec727abc717e342af25f772da50deb1152)): ?>
<?php $component = $__componentOriginaldba46aec727abc717e342af25f772da50deb1152; ?>
<?php unset($__componentOriginaldba46aec727abc717e342af25f772da50deb1152); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    
                    <!--
                        bootstrap pagination
                    -->
                    
                </div>
            </div>
        </div>
    </div>

     <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rifat\Desktop\MKSSDEV\mkss\resources\views/public/pages/project.blade.php ENDPATH**/ ?>
<div class="project-item">
    <div class="card">
        <div class="card-img-top">
            <img src="<?php echo e(asset("image/project/$image")); ?>" alt="" class="img-fluid">
            <div class="overlay-2"></div>
            <div class="tag">
                <span><?php echo e($sector); ?></span>
            </div>
        </div>
        <div class="card-footer">
            <div class="project-status <?php echo e($status == 1 ? 'running-project' : 'archieved-project'); ?>"><?php echo e($status == 1 ? 'active' : 'archieved'); ?></div>
            <div class="project-duration"><i class="fas fa-clock"></i><?php echo e($from); ?> - <?php echo e($to ?? 'running'); ?></div>
            <a href="">
                <h3 class="project-title"><?php echo e($title); ?></h3>
            </a>
            
            <a href="/project/<?php echo e($url); ?>"><button class="cbtn" >More<i class="fas fa-angle-double-right"></i></button></a>
        </div>
    </div>
</div><?php /**PATH C:\Users\rifat\Desktop\MKSSDEV\mkss\resources\views/public/components/project-item.blade.php ENDPATH**/ ?>
<div class="news-item">
    <div class="card">
        <div class="card-header"></div>
        <div class="card-img-wraper">
            <img src="<?php echo e(asset("image/news/$image")); ?>" alt="" class="card-img-top img-fluid">
        </div>
        
        
        <div class="card-footer">
            <div class="news-info">
                <span class="news-category">
                   
                    <?php echo e($category); ?>

                    
                </span>
                <div class="date">
                    <i class="fa fa-calendar-alt"></i>
                    <?php echo e($date); ?>

                </div>
                <a href="/<?php echo e($url); ?>">
                     <h3><?php echo e($title); ?></h3>
                </a>
             </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\rifat\Desktop\MKSSDEV\mkss\resources\views/public/components/news-item.blade.php ENDPATH**/ ?>
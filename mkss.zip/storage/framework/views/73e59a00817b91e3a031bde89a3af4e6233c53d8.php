

<?php $__env->startSection("main"); ?>

 <?php if (isset($component)) { $__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Navigation::class, ['current' => 'f']); ?>
<?php $component->withName('navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e)): ?>
<?php $component = $__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e; ?>
<?php unset($__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<div class="container">
    <div class="single-project">
        <div class="col-lg-9 single-project-inner-container">
            <div class="single-project-title">
                <h1><?php echo e($project->title); ?></h1>
            </div>
           
            <div class="single-project-duration">
                <p><i class="fa fa-clock"></i><?php echo e($project->from); ?> - <?php echo e($project->to); ?></p>
            </div>
            <div class="project-status <?php echo e($project->status == 1 ? 'running-project' : 'archieved-project'); ?>"><?php echo e($project->status == 1 ? 'active' : 'archieved'); ?></div>
            <hr>
            <div class="single-project-image">
                <div class="">
                    <img src='<?php echo e(asset("image/project/$project->image")); ?>' alt="<?php echo e($project->image); ?>" class="img-fluid">
                </div>
            </div>
            <div class="single-project-sector">
                <p><?php echo e($project->sector); ?></p>
            </div>
            <div class="single-project-working-zone">
                <p>Working Zone : <b><?php echo e($project->area); ?></b></p>
            </div>
            <hr class="bellow-img">
            <div class="single-project-description">
                <?php echo e($project->description); ?>

            </div>
        </div>

        
        <div class="col-lg-3">

        </div>
        
    </div>
</div>

 <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make("public.layout.app", ["page_title" => str_replace("-", " ", $project->title)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rifat\Desktop\MKSSDEV\mkss\resources\views/public/pages/single-project.blade.php ENDPATH**/ ?>
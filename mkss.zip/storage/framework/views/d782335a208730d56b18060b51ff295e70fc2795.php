<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($page_title ?? "This is Title"); ?></title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Maven+Pro:wght@400;500;600&family=Montserrat:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <style>
        .running-project{
            background : #28a745;
            color : #fff;
        }

        .archieved-project{
            background : #6c757d;
            color : #fff;
        }

        .no-project-alert{
            font-size: 1.5rem;
            padding : 1rem 2rem;
        }
        
    </style>
     <?php echo $__env->yieldContent('style'); ?>

</head>
<body>
    
    <?php echo $__env->yieldContent('main'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html><?php /**PATH C:\Users\rifat\Desktop\MKSSDEV\mkss\resources\views/public/layout/app.blade.php ENDPATH**/ ?>